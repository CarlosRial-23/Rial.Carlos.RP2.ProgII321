package service;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import service.CSVSerializable;

public interface Gestionable<T extends CSVSerializable & Comparable<T>> {
    
    void agregar(T item);
    
    T eliminar(int id);
    
    T obtener(int indice);
    
    void limpiar(List<T> lista);
    
    void ordenar();
    
    void ordenar(Comparator<T> comparator); 
    
    List<T> filtrar(Predicate<T> predicate);
    
    //Guardar y cargar elementos desde archivos binarios.
    
    void guardarEnBinario(String path);
    
    void cargarDesdeBinario(String path);
    //guardarEnBinario y cargarDesdeBinario main
    void guardarEnCSV(String path);
    
    void cargarDesdeCSV(String path,  Function<String,T> function);
    
    void mostrarTodos();
    
}

