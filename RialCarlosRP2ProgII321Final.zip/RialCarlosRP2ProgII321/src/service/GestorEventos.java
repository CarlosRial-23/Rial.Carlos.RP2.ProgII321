package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;



public class GestorEventos<T extends CSVSerializable & Comparable<T>> implements Gestionable<T>{

    private List<T> items = new ArrayList<>();
    
    @Override
    public void agregar(T item) {
        if(item == null){
            throw new IllegalArgumentException("No puedo inventariar algo nulo");
        }
        items.add(item);
    }

    @Override
    public T eliminar(int indice) {
        validarIndice(indice);
        return items.remove(indice);
    }

    private void validarIndice(int indice){
        if(!(indice>0 && indice<items.size())){
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }
    
    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }

    @Override
    public void limpiar(List<T> lista) {
        lista.clear();
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        items.sort(comparator);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicate) {
        List<T> toReturn = new ArrayList<>();
        for (T item : items) {
            if(predicate.test(item)){
                toReturn.add(item);
            }         
        }
        return toReturn;
    }

    /*
    void guardarEnArchivo(String path);
    public void deserializar(String path) throws IOException, ClassNotFoundException{
        lista.clear();
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path));
        lista.addAll((List<T>) entrada.readObject()) ;
        entrada.close();
    }
    void cargarArchivo(String path);
    */
    
    @Override
    public void guardarEnBinario(String path) {
        
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            
            salida.writeObject(items);
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
    @Override
    public void cargarDesdeBinario(String path){
        
        items.clear();
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))){
            
            items.addAll((List<T>) entrada.readObject());
            
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
    @Override
    public void guardarEnCSV(String path) {
        
        File archivo = new File(path);
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){
            bw.write(items.get(0).toHeaderCSV() + "\n");
            
            for(T item : items){
                bw.write(item.toCSV() + "\n");
            }
        }catch (IOException ex){
            System.out.println(ex.getMessage());
        }
        
        
        
    }

    
    @Override
    public void cargarDesdeCSV(String path, Function<String,T> function) {
        List<T> toReturn = new ArrayList<>();
        File archivo = new File(path);
        try ( BufferedReader br = new BufferedReader(new FileReader(archivo))){
            
            String linea;
            br.readLine();
            
            while ((linea = br.readLine()) != null) {
                
                if(linea.endsWith("\n")){
                   
                    linea = linea.substring(linea.length() - 1);
                    
                }
                
                toReturn.add(function.apply(linea));
                
            }
    }catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    

    @Override
    public void mostrarTodos() {
        for (T item : items) {
            System.out.println(item);
        }
    }

    

}
